-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2024 at 05:22 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_starlighthotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_addons`
--

CREATE TABLE `tbl_addons` (
  `addOns_ID` int(11) NOT NULL,
  `nameOfAddOns` varchar(15) NOT NULL,
  `priceAddOns` int(11) NOT NULL,
  `booking_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_addons`
--

INSERT INTO `tbl_addons` (`addOns_ID`, `nameOfAddOns`, `priceAddOns`, `booking_ID`) VALUES
(1, 'Blanket', 750, 1),
(2, 'Pillow', 300, 1),
(3, 'Toiletries', 600, 1),
(4, 'Blanket', 750, 2),
(5, 'Pillow', 300, 2),
(6, 'Toiletries', 600, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_amenities`
--

CREATE TABLE `tbl_amenities` (
  `amenities_ID` int(11) NOT NULL,
  `nameOfAmenities` varchar(25) NOT NULL,
  `discountTotal` decimal(11,2) NOT NULL,
  `priceAmenities` decimal(11,2) NOT NULL,
  `booking_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_amenities`
--

INSERT INTO `tbl_amenities` (`amenities_ID`, `nameOfAmenities`, `discountTotal`, `priceAmenities`, `booking_ID`) VALUES
(1, 'Swimming Pool', 60.00, 60.00, 1),
(2, 'Gym', 0.00, 2000.00, 1),
(3, 'Foot Spa', 0.00, 7425.00, 1),
(4, 'Aroma Facial Massage', 0.00, 9405.00, 1),
(5, 'Thai Massage', 0.00, 13860.00, 1),
(6, 'Swimming Pool', 60.00, 360.00, 2),
(7, 'Gym', 200.00, 1200.00, 2),
(8, 'Foot Spa', 495.00, 5445.00, 2),
(9, 'Aroma Facial Massage', 627.00, 10032.00, 2),
(10, 'Thai Massage', 1232.00, 25872.00, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bedextracharge`
--

CREATE TABLE `tbl_bedextracharge` (
  `bed_ID` int(11) NOT NULL,
  `priceExtraCharge` int(11) NOT NULL,
  `booking_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_bedextracharge`
--

INSERT INTO `tbl_bedextracharge` (`bed_ID`, `priceExtraCharge`, `booking_ID`) VALUES
(1, 0, 1),
(2, 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bookingdetails`
--

CREATE TABLE `tbl_bookingdetails` (
  `booking_ID` int(11) NOT NULL,
  `user_ID` int(11) NOT NULL,
  `checkInDate` date NOT NULL,
  `checkOutDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_bookingdetails`
--

INSERT INTO `tbl_bookingdetails` (`booking_ID`, `user_ID`, `checkInDate`, `checkOutDate`) VALUES
(1, 1, '2024-12-20', '2024-12-25'),
(2, 1, '2025-01-01', '2025-01-05');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guestdetails`
--

CREATE TABLE `tbl_guestdetails` (
  `guest_ID` int(11) NOT NULL,
  `adultGuests` int(11) NOT NULL,
  `childGuests` int(11) NOT NULL,
  `totalGuests` int(11) NOT NULL,
  `numToAvailBed` int(11) NOT NULL,
  `booking_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_guestdetails`
--

INSERT INTO `tbl_guestdetails` (`guest_ID`, `adultGuests`, `childGuests`, `totalGuests`, `numToAvailBed`, `booking_ID`) VALUES
(1, 4, 2, 6, 4, 1),
(2, 3, 3, 6, 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_international`
--

CREATE TABLE `tbl_international` (
  `international_ID` int(11) NOT NULL,
  `tripType` varchar(20) NOT NULL,
  `booking_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_international`
--

INSERT INTO `tbl_international` (`international_ID`, `tripType`, `booking_ID`) VALUES
(1, 'International', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_internationaldesti`
--

CREATE TABLE `tbl_internationaldesti` (
  `internationalDesti_ID` int(11) NOT NULL,
  `destination` varchar(20) NOT NULL,
  `booking_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_internationaldesti`
--

INSERT INTO `tbl_internationaldesti` (`internationalDesti_ID`, `destination`, `booking_ID`) VALUES
(1, 'Hong Kong', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_local`
--

CREATE TABLE `tbl_local` (
  `local_ID` int(11) NOT NULL,
  `tripType` varchar(20) NOT NULL,
  `booking_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_local`
--

INSERT INTO `tbl_local` (`local_ID`, `tripType`, `booking_ID`) VALUES
(1, 'Local', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_localdesti`
--

CREATE TABLE `tbl_localdesti` (
  `localDesti_ID` int(11) NOT NULL,
  `destination` varchar(20) NOT NULL,
  `booking_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_localdesti`
--

INSERT INTO `tbl_localdesti` (`localDesti_ID`, `destination`, `booking_ID`) VALUES
(1, 'Siargao', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_roomtype`
--

CREATE TABLE `tbl_roomtype` (
  `roomtype_ID` int(11) NOT NULL,
  `nameOfRoomtype` varchar(10) NOT NULL,
  `priceRoomType` int(11) NOT NULL,
  `booking_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_roomtype`
--

INSERT INTO `tbl_roomtype` (`roomtype_ID`, `nameOfRoomtype`, `priceRoomType`, `booking_ID`) VALUES
(1, 'Quadruple', 15000, 1),
(2, 'Suite', 22000, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_season`
--

CREATE TABLE `tbl_season` (
  `season_ID` int(11) NOT NULL,
  `season` varchar(20) NOT NULL,
  `booking_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_season`
--

INSERT INTO `tbl_season` (`season_ID`, `season`, `booking_ID`) VALUES
(1, 'Super Peak', 1),
(2, 'Super Peak', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_totaltopay`
--

CREATE TABLE `tbl_totaltopay` (
  `toPay_ID` int(11) NOT NULL,
  `totalSum` decimal(11,2) DEFAULT NULL,
  `booking_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_totaltopay`
--

INSERT INTO `tbl_totaltopay` (`toPay_ID`, `totalSum`, `booking_ID`) VALUES
(1, 109400.00, 1),
(2, 132559.00, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_usercredentials`
--

CREATE TABLE `tbl_usercredentials` (
  `auth_ID` int(11) NOT NULL,
  `user_ID` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_usercredentials`
--

INSERT INTO `tbl_usercredentials` (`auth_ID`, `user_ID`, `username`, `password`) VALUES
(1, 1, 'ruffaina', '123qwerty');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_userpersonaldetails`
--

CREATE TABLE `tbl_userpersonaldetails` (
  `user_ID` int(11) NOT NULL,
  `firstName` varchar(25) NOT NULL,
  `lastName` varchar(25) NOT NULL,
  `age` int(11) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_userpersonaldetails`
--

INSERT INTO `tbl_userpersonaldetails` (`user_ID`, `firstName`, `lastName`, `age`, `contact`, `email`) VALUES
(1, 'ruffaina', 'hamsain', 20, '09260645112', 'ruffaina@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_addons`
--
ALTER TABLE `tbl_addons`
  ADD PRIMARY KEY (`addOns_ID`),
  ADD KEY `booking_ID` (`booking_ID`);

--
-- Indexes for table `tbl_amenities`
--
ALTER TABLE `tbl_amenities`
  ADD PRIMARY KEY (`amenities_ID`),
  ADD KEY `booking_ID` (`booking_ID`);

--
-- Indexes for table `tbl_bedextracharge`
--
ALTER TABLE `tbl_bedextracharge`
  ADD PRIMARY KEY (`bed_ID`),
  ADD KEY `booking_ID` (`booking_ID`);

--
-- Indexes for table `tbl_bookingdetails`
--
ALTER TABLE `tbl_bookingdetails`
  ADD PRIMARY KEY (`booking_ID`),
  ADD KEY `user_ID` (`user_ID`);

--
-- Indexes for table `tbl_guestdetails`
--
ALTER TABLE `tbl_guestdetails`
  ADD PRIMARY KEY (`guest_ID`),
  ADD KEY `booking_ID` (`booking_ID`);

--
-- Indexes for table `tbl_international`
--
ALTER TABLE `tbl_international`
  ADD PRIMARY KEY (`international_ID`),
  ADD KEY `booking_ID` (`booking_ID`);

--
-- Indexes for table `tbl_internationaldesti`
--
ALTER TABLE `tbl_internationaldesti`
  ADD PRIMARY KEY (`internationalDesti_ID`),
  ADD KEY `booking_ID` (`booking_ID`);

--
-- Indexes for table `tbl_local`
--
ALTER TABLE `tbl_local`
  ADD PRIMARY KEY (`local_ID`),
  ADD KEY `booking_ID` (`booking_ID`);

--
-- Indexes for table `tbl_localdesti`
--
ALTER TABLE `tbl_localdesti`
  ADD PRIMARY KEY (`localDesti_ID`),
  ADD KEY `booking_ID` (`booking_ID`);

--
-- Indexes for table `tbl_roomtype`
--
ALTER TABLE `tbl_roomtype`
  ADD PRIMARY KEY (`roomtype_ID`),
  ADD KEY `booking_ID` (`booking_ID`);

--
-- Indexes for table `tbl_season`
--
ALTER TABLE `tbl_season`
  ADD PRIMARY KEY (`season_ID`),
  ADD KEY `booking_ID` (`booking_ID`);

--
-- Indexes for table `tbl_totaltopay`
--
ALTER TABLE `tbl_totaltopay`
  ADD PRIMARY KEY (`toPay_ID`),
  ADD KEY `booking_ID` (`booking_ID`);

--
-- Indexes for table `tbl_usercredentials`
--
ALTER TABLE `tbl_usercredentials`
  ADD PRIMARY KEY (`auth_ID`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `user_ID` (`user_ID`);

--
-- Indexes for table `tbl_userpersonaldetails`
--
ALTER TABLE `tbl_userpersonaldetails`
  ADD PRIMARY KEY (`user_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_addons`
--
ALTER TABLE `tbl_addons`
  MODIFY `addOns_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_amenities`
--
ALTER TABLE `tbl_amenities`
  MODIFY `amenities_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_bedextracharge`
--
ALTER TABLE `tbl_bedextracharge`
  MODIFY `bed_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_bookingdetails`
--
ALTER TABLE `tbl_bookingdetails`
  MODIFY `booking_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_guestdetails`
--
ALTER TABLE `tbl_guestdetails`
  MODIFY `guest_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_international`
--
ALTER TABLE `tbl_international`
  MODIFY `international_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_internationaldesti`
--
ALTER TABLE `tbl_internationaldesti`
  MODIFY `internationalDesti_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_local`
--
ALTER TABLE `tbl_local`
  MODIFY `local_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_localdesti`
--
ALTER TABLE `tbl_localdesti`
  MODIFY `localDesti_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_roomtype`
--
ALTER TABLE `tbl_roomtype`
  MODIFY `roomtype_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_season`
--
ALTER TABLE `tbl_season`
  MODIFY `season_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_totaltopay`
--
ALTER TABLE `tbl_totaltopay`
  MODIFY `toPay_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_usercredentials`
--
ALTER TABLE `tbl_usercredentials`
  MODIFY `auth_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_userpersonaldetails`
--
ALTER TABLE `tbl_userpersonaldetails`
  MODIFY `user_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_addons`
--
ALTER TABLE `tbl_addons`
  ADD CONSTRAINT `tbl_addons_ibfk_1` FOREIGN KEY (`booking_ID`) REFERENCES `tbl_bookingdetails` (`booking_ID`);

--
-- Constraints for table `tbl_amenities`
--
ALTER TABLE `tbl_amenities`
  ADD CONSTRAINT `tbl_amenities_ibfk_1` FOREIGN KEY (`booking_ID`) REFERENCES `tbl_bookingdetails` (`booking_ID`);

--
-- Constraints for table `tbl_bedextracharge`
--
ALTER TABLE `tbl_bedextracharge`
  ADD CONSTRAINT `tbl_bedextracharge_ibfk_1` FOREIGN KEY (`booking_ID`) REFERENCES `tbl_bookingdetails` (`booking_ID`);

--
-- Constraints for table `tbl_bookingdetails`
--
ALTER TABLE `tbl_bookingdetails`
  ADD CONSTRAINT `tbl_bookingdetails_ibfk_1` FOREIGN KEY (`user_ID`) REFERENCES `tbl_userpersonaldetails` (`user_ID`);

--
-- Constraints for table `tbl_guestdetails`
--
ALTER TABLE `tbl_guestdetails`
  ADD CONSTRAINT `tbl_guestdetails_ibfk_1` FOREIGN KEY (`booking_ID`) REFERENCES `tbl_bookingdetails` (`booking_ID`);

--
-- Constraints for table `tbl_international`
--
ALTER TABLE `tbl_international`
  ADD CONSTRAINT `tbl_international_ibfk_1` FOREIGN KEY (`booking_ID`) REFERENCES `tbl_bookingdetails` (`booking_ID`);

--
-- Constraints for table `tbl_internationaldesti`
--
ALTER TABLE `tbl_internationaldesti`
  ADD CONSTRAINT `tbl_internationaldesti_ibfk_1` FOREIGN KEY (`booking_ID`) REFERENCES `tbl_bookingdetails` (`booking_ID`);

--
-- Constraints for table `tbl_local`
--
ALTER TABLE `tbl_local`
  ADD CONSTRAINT `tbl_local_ibfk_1` FOREIGN KEY (`booking_ID`) REFERENCES `tbl_bookingdetails` (`booking_ID`);

--
-- Constraints for table `tbl_localdesti`
--
ALTER TABLE `tbl_localdesti`
  ADD CONSTRAINT `tbl_localdesti_ibfk_1` FOREIGN KEY (`booking_ID`) REFERENCES `tbl_bookingdetails` (`booking_ID`);

--
-- Constraints for table `tbl_roomtype`
--
ALTER TABLE `tbl_roomtype`
  ADD CONSTRAINT `tbl_roomtype_ibfk_1` FOREIGN KEY (`booking_ID`) REFERENCES `tbl_bookingdetails` (`booking_ID`);

--
-- Constraints for table `tbl_season`
--
ALTER TABLE `tbl_season`
  ADD CONSTRAINT `tbl_season_ibfk_1` FOREIGN KEY (`booking_ID`) REFERENCES `tbl_bookingdetails` (`booking_ID`);

--
-- Constraints for table `tbl_totaltopay`
--
ALTER TABLE `tbl_totaltopay`
  ADD CONSTRAINT `tbl_totaltopay_ibfk_1` FOREIGN KEY (`booking_ID`) REFERENCES `tbl_bookingdetails` (`booking_ID`);

--
-- Constraints for table `tbl_usercredentials`
--
ALTER TABLE `tbl_usercredentials`
  ADD CONSTRAINT `tbl_usercredentials_ibfk_1` FOREIGN KEY (`user_ID`) REFERENCES `tbl_userpersonaldetails` (`user_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
